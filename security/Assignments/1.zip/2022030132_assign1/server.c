#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define FAIL -1

int OpenListener(int port) {
    int sd;
    struct sockaddr_in addr;

    sd = socket(PF_INET, SOCK_STREAM, 0);
    bzero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sd, (struct sockaddr*)&addr, sizeof(addr)) != 0) {
        perror("Can't bind port");
        abort();
    }

    if (listen(sd, 10) != 0) {
        perror("Can't configure listening port");
        abort();
    }

    return sd;
}

SSL_CTX* InitServerCTX(void) {
    /* TODO:
     * 1. Initialize SSL library (SSL_library_init, OpenSSL_add_all_algorithms, SSL_load_error_strings)
     */

    SSL_library_init();
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();

      /* 2. Create a new TLS server context (TLS_server_method)*/

    const SSL_METHOD *method = TLS_server_method();
    SSL_CTX *ctx = SSL_CTX_new(method);
    if (!ctx) {
        ERR_print_errors_fp(stderr);
        abort();
    }

     /* 3. Load CA certificate for client verification*/

    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT, NULL);							
    /* 4. Configure SSL_CTX to require client certificate (mutual TLS)
*/

    // CA για να επαληθεύουμε το client cert
    // if loading fails, we print errors and we abort
    if (!SSL_CTX_load_verify_locations(ctx, "certs/ca.crt", NULL)) {
        ERR_print_errors_fp(stderr);
        abort();
    }
	// returning initialized SSL context
    return ctx;

}

void LoadCertificates(SSL_CTX* ctx, char* CertFile, char* KeyFile) {
    /* TODO:
     * 1. Load server certificate
     */

// we load  the server’s certificate from the specified file.
    if (SSL_CTX_use_certificate_file(ctx, CertFile, SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        abort();
 //we load  the server’s private key from the specified file.
    }
    if (SSL_CTX_use_PrivateKey_file(ctx, KeyFile, SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        abort();
    }
// we verify that the private key matches the loaded certificate.
    if (!SSL_CTX_check_private_key(ctx)) {
        fprintf(stderr, "Server private key does not match certificate\n");
        abort();
    }
}

void ShowCerts(SSL* ssl) {
/* TODO:
     * 1. Get client certificate (if any) using SSL_get_peer_certificate
     * 2. Print Subject and Issuer names
     */
     X509 *cert = SSL_get_peer_certificate(ssl);
	// printing subject info
    if (cert != NULL) {
        char *line = X509_NAME_oneline(X509_get_subject_name(cert), 0, 0);
        printf("Client certificate subject: %s\n", line);
        free(line);
	//printing issuer info
        line = X509_NAME_oneline(X509_get_issuer_name(cert), 0, 0);
        printf("Client certificate issuer: %s\n", line);
        free(line);
        X509_free(cert);
    } else { // in case no client certificate
        printf("No client certificate presented.\n");
    }
}

void Servlet(SSL* ssl) {
   char buf[1024] = {0};

    if (SSL_accept(ssl) == FAIL) {
        ERR_print_errors_fp(stderr);
        return;
    }

    ShowCerts(ssl);

    int bytes = SSL_read(ssl, buf, sizeof(buf));
    if (bytes <= 0) {
        SSL_free(ssl);
        return;
    }
    buf[bytes] = '\0';
    printf("Client message: %s\n", buf);

    /* TODO:
     * 1. Parse XML from client message to extract username and password
     * . Compare credentials to predefined values (e.g., "sousi"/"123")
     * 3. Send appropriate XML response back to client
     */
    //XML 
char username[128] = {0};
char password[128] = {0};

const char *u1 = "<UserName>", *u2 = "</UserName>";
const char *p1 = "<Password>", *p2 = "</Password>";

int have_user = 0, have_pass = 0;

// username
char *us = strstr(buf, u1);
char *ue = strstr(buf, u2);
if (us && ue && ue > us) {
    us += strlen(u1);
    size_t len = (size_t)(ue - us);
    if (len >= sizeof(username)) len = sizeof(username) - 1;
    memcpy(username, us, len);
    username[len] = '\0';
    have_user = 1;
}

// password
char *ps = strstr(buf, p1);
char *pe = strstr(buf, p2);
if (ps && pe && pe > ps) {
    ps += strlen(p1);
    size_t len = (size_t)(pe - ps);
    if (len >= sizeof(password)) len = sizeof(password) - 1;
    memcpy(password, ps, len);
    password[len] = '\0';
    have_pass = 1;
}


if (have_user && have_pass &&
    strcmp(username, "sousi") == 0 &&
    strcmp(password, "123") == 0) {

    const char *ok_reply =
        "<Body>"
          "<Name>sousi.com</Name>"
          "<year>1.5</year>"
          "<BlogType>Embedded and C/C++</BlogType>"
          "<Author>John Johny</Author>"
        "</Body>";
    SSL_write(ssl, ok_reply, (int)strlen(ok_reply));
} else { // in case of error
    const char *invalid = "Invalid Message";
    SSL_write(ssl, invalid, (int)strlen(invalid));
}
   //XML END

	// closung  TLS session 
	SSL_shutdown(ssl);     // sends "close_notify"
	SSL_shutdown(ssl);     //waits for "close_notify" from client

	int sd = SSL_get_fd(ssl);
	SSL_free(ssl);
	close(sd);

}

int main(int argc, char *argv[]) {
     if (argc != 2) {
        printf("Usage: %s <port>\n", argv[0]);
        exit(0);
    }

    int port = atoi(argv[1]);
    SSL_CTX *ctx;

    SSL_library_init();
    OpenSSL_add_all_algorithms();
    SSL_load_error_strings();

    ctx = InitServerCTX();
    LoadCertificates(ctx, "certs/server.crt", "certs/server.key");

    int server = OpenListener(port);
    printf("Server listening on port %d...\n", port);

    while (1) {
        struct sockaddr_in addr;
        socklen_t len = sizeof(addr);
        SSL *ssl;

        int client = accept(server, (struct sockaddr*)&addr, &len);
        printf("Connection from %s:%d\n", inet_ntoa(addr.sin_addr), ntohs(addr.sin_port));

        ssl = SSL_new(ctx);
        SSL_set_fd(ssl, client);
        Servlet(ssl);
    }

    close(server);
    SSL_CTX_free(ctx);
    return 0;
}
