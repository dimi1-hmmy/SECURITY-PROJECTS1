#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define FAIL -1

int OpenConnection(const char *hostname, int port)
{
    int sd;
    struct hostent *host;
    struct sockaddr_in addr;

    if ((host = gethostbyname(hostname)) == NULL)
    {
        perror(hostname);
        abort();
    }

    sd = socket(PF_INET, SOCK_STREAM, 0);
    bzero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = *(long*)(host->h_addr);

    if (connect(sd, (struct sockaddr*)&addr, sizeof(addr)) != 0)
    {
        close(sd);
        perror("Connection failed");
        abort();
    }

    return sd;
}

SSL_CTX* InitCTX(void)
{

    SSL_library_init();
    OpenSSL_add_all_algorithms();
    SSL_load_error_strings();

    const SSL_METHOD *method = TLS_client_method();
    SSL_CTX *ctx = SSL_CTX_new(method);
    if (ctx == NULL)
    {
        ERR_print_errors_fp(stderr);
        abort();
    }

    
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);

    
    if (!SSL_CTX_load_verify_locations(ctx, "certs/ca.crt", NULL)) {
        ERR_print_errors_fp(stderr);
        abort();
    }

    return ctx;
}

void LoadCertificates(SSL_CTX* ctx, char* CertFile, char* KeyFile)
{
    
  
    if (SSL_CTX_use_certificate_file(ctx, CertFile, SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        abort();
    }
    
    if (SSL_CTX_use_PrivateKey_file(ctx, KeyFile, SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        abort();
    }
    
    if (!SSL_CTX_check_private_key(ctx)) {
        fprintf(stderr, "Client private key does not match certificate\n");
        abort();
    }
}


int main(int argc, char *argv[])
{
    if (argc != 3)
  {
        printf("Usage: %s <hostname> <port>\n", argv[0]);
        exit(0);
    }

     char *hostname = argv[1];
    int port = atoi(argv[2]);
    SSL_CTX *ctx;
    SSL *ssl;
    int server;

    //differentiation between client and rogue client
    //using fake certificate and key for rogue client
    ctx = InitCTX();
    LoadCertificates(ctx, "certs/rclient.crt", "certs/rclient.key");

    server = OpenConnection(hostname, port);

    ssl = SSL_new(ctx);
    SSL_set_fd(ssl, server);

    
    if (SSL_connect(ssl) <= 0) {
        ERR_print_errors_fp(stderr);
        SSL_free(ssl);
        close(server);
        SSL_CTX_free(ctx);
        return 1;
    }

    
   
   const char *msg = "<Body><UserName>rogue</UserName><Password>bad</Password></Body>\n";

    if (SSL_write(ssl, msg, (int)strlen(msg)) <= 0) {
        ERR_print_errors_fp(stderr);
    }

    
    char buf[4096];
    int n = SSL_read(ssl, buf, sizeof(buf)-1);
    if (n > 0) {
        buf[n] = '\0';
        printf("%s", buf);
    }

    
    SSL_shutdown(ssl);
    SSL_shutdown(ssl);

    SSL_free(ssl);
    close(server);
    SSL_CTX_free(ctx);
    return 0;  
}


