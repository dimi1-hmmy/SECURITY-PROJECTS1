
SSL Assignment01 – Mutual TLS + XML Authentication


Author: RAPTOPOULOU DIMITRA,ELIZA POLYZOU
AM :  2022030132,2022030131
Date: 30/10/2025

-------------------------------------------------------------------------
1. Description
-------------------------------------------------------------------------
This project implements a simple SSL/TLS client-server communication with mutual authentication.
The client and server exchange certificates signed by a CA (Certificate Authority).
The client sends an XML message containing login credentials, and the server validates them.
A rogue client (rclient) with a fake certificate is rejected by the server.

-------------------------------------------------------------------------
2. Files
-------------------------------------------------------------------------
- client.c      : The legitimate client that connects with a valid certificate.
- rclient.c     : The rogue client using a fake certificate signed by a rogue CA.
- server.c      : The SSL/TLS server that validates the client certificate and XML data.
- Makefile      : Compiles all three programs (client, rclient, server).

-------------------------------------------------------------------------
3. Certificate Generation Commands
------------------------------------------------------------------------
# Step 1 – Create CA (Root Authority)
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
-keyout ca.key -out ca.crt -subj "/C=GR/O=ECE_Lab/CN=RootCA"

# Step 2 – Create server certificate request and sign
openssl req -newkey rsa:2048 -nodes -keyout server.key -out server.csr \
-subj "/C=GR/ST=Crete/L=Chania/O=TechnicalUniversityofCrete/OU=ECE_Lab/CN=server"
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
-out server.crt -days 365 -sha256

# Step 3 – Create client certificate request and sign
openssl req -newkey rsa:2048 -nodes -keyout client.key -out client.csr \
-subj "/C=GR/ST=Crete/L=Chania/O=TechnicalUniversityofCrete/OU=ECE_Lab/CN=client"
openssl x509 -req -in client.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
-out client.crt -days 365 -sha256

# Step 4 – Create Rogue CA and Rogue Client
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
-keyout rogue_ca.key -out rogue_ca.crt -subj "/C=GR/O=RogueSecurity/CN=RogueCA"

openssl req -newkey rsa:2048 -nodes -keyout rclient.key -out rclient.csr \
-subj "/C=GR/O=RogueSecurity/CN=rogue_client"
openssl x509 -req -in rclient.csr -CA rogue_ca.crt -CAkey rogue_ca.key \
-CAcreateserial -out rclient.crt -days 365 -sha256

-------------------------------------------------------------------------
4. Compile
-------------------------------------------------------------------------
make all
# or separately:
make server
make client
make rclient

-------------------------------------------------------------------------
5. Run
------------------------------------------------------------------------
# Terminal 1 – Start server
./server 8082

# Terminal 2 – Run legitimate client
./client 127.0.0.1 8082

Expected result:
<response>OK</response>

# Terminal 3 – Run rogue client
./rclient 127.0.0.1 8082

Expected result:
Server prints: certificate verify failed

---------------------------------------------------------------------
6. Parameters
--------------------------------------------------------------------
-x509: creates a self-signed certificate.
-nodes: no DES encryption on the private key (no password).
-days 365: certificate validity (1 year).
-newkey rsa:2048: generate new RSA key pair.
-CA / -CAkey: use CA’s certificate and key to sign another certificate.
-CAcreateserial: create a serial number for the signed certificate.
-subj: specifies the subject (C=Country, O=Organization, CN=Common Name).
SSL_CTX_use_certificate_file: loads the certificate.
SSL_CTX_check_private_key: checks if key and certificate match.

--------------------------
7. Result
--------------------------
-Secure SSL/TLS handshake between client and server
-XML exchange with username/password
-Rogue client rejected due to invalid CA
-Correct TLS shutdown
