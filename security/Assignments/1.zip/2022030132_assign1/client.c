#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define FAIL -1

int OpenConnection(const char *hostname, int port)
{
    int sd;
    struct hostent *host;
    struct sockaddr_in addr;

    if ((host = gethostbyname(hostname)) == NULL)
    {
        perror(hostname);
        abort();
    }

    sd = socket(PF_INET, SOCK_STREAM, 0);
    bzero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = *(long*)(host->h_addr);

    if (connect(sd, (struct sockaddr*)&addr, sizeof(addr)) != 0)
    {
        close(sd);
        perror("Connection failed");
        abort();
    }

    return sd;
}

SSL_CTX* InitCTX(void)
{
    // initializing  SSL library (SSL_library_init, OpenSSL_add_all_algorithms,SSL_load_error_strings)

    SSL_library_init();
    OpenSSL_add_all_algorithms();
    SSL_load_error_strings();

    //creating  a new SSL/TLS context for the client
    const SSL_METHOD *method = TLS_client_method();
    SSL_CTX *ctx = SSL_CTX_new(method);
    if (ctx == NULL)
    {
        ERR_print_errors_fp(stderr);
        abort();
    }

    // requiring verification of the server certificate 
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);

    //loading the trusted CA certificate to verify the server's identity
    if (!SSL_CTX_load_verify_locations(ctx, "certs/ca.crt", NULL)) {
        ERR_print_errors_fp(stderr);
        abort();
    }

    return ctx;
}

void LoadCertificates(SSL_CTX* ctx, char* CertFile, char* KeyFile)
{
    
  //loading the client certificate
    if (SSL_CTX_use_certificate_file(ctx, CertFile, SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        abort();
    }
    //loading  the  client private key
    if (SSL_CTX_use_PrivateKey_file(ctx, KeyFile, SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        abort();
    }
    // checking they match each other
    if (!SSL_CTX_check_private_key(ctx)) {
        fprintf(stderr, "Client private key does not match certificate\n");
        abort();
    }
}


int main(int argc, char *argv[])
{
    if (argc != 3)
  {
        printf("Usage: %s <hostname> <port>\n", argv[0]);
        exit(0);
    }

     char *hostname = argv[1];
    int port = atoi(argv[2]);
    SSL_CTX *ctx;
    SSL *ssl;
    int server;

    //  initing SSL context and  loading  client cert/key */
    ctx = InitCTX();
    LoadCertificates(ctx, "certs/client.crt", "certs/client.key");

    server = OpenConnection(hostname, port);

    ssl = SSL_new(ctx);
    SSL_set_fd(ssl, server);

    /*  handshake */
    if (SSL_connect(ssl) <= 0) {
        ERR_print_errors_fp(stderr);
        SSL_free(ssl);
        close(server);
        SSL_CTX_free(ctx);
        return 1;
    }

    
    // simple message example:
   // const char *msg = "hello\n";
    // XML
     const char *msg = "<Body><UserName>sousi</UserName><Password>123</Password></Body>\n";

    if (SSL_write(ssl, msg, (int)strlen(msg)) <= 0) {
        ERR_print_errors_fp(stderr);
    }

    /* reading  server respond */
    char buf[4096];
    int n = SSL_read(ssl, buf, sizeof(buf)-1);
    if (n > 0) {
        buf[n] = '\0';
        printf("%s", buf);
    }

    /*closing the TLS session gracefully to avoid unexpected EOF on the peer. */
    SSL_shutdown(ssl);
    SSL_shutdown(ssl);

    SSL_free(ssl);
    close(server);
    SSL_CTX_free(ctx);
    return 0;  
}


