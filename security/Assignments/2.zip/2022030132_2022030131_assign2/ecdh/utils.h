#ifndef UTILS_RSA_H
#define UTILS_RSA_H

#include <stdio.h>
#include <stdbool.h>
#include <gmp.h>
#include <sodium.h>

void write_mpz_to_file(FILE *fp, const char *label, const mpz_t x);
bool load_key_component(mpz_t out, const char *label, FILE *fp);
bool compute_sha256(const char *path, unsigned char out[crypto_hash_sha256_BYTES]);

#endif

