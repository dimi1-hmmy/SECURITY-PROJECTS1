#include <sodium.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>   // getopt
#include <errno.h>

// we define the keys' length according to libsodium (32-byte scalars/keys for X25519)
#define SECRETKEY_BYTES   crypto_scalarmult_SCALARBYTES  // 32 bytes for private key
#define PUBLICKEY_BYTES   crypto_scalarmult_BYTES        // 32  bytes for public key
#define SESSIONKEY_BYTES  crypto_scalarmult_BYTES        // 32 (shared secret)
                                                         // scalar multiplication (public key)*(private key)
#define KDF_KEY_LENGTH    32                             // 32 bytes for derived keys
#define KDF_CONTEXT_BYTES crypto_kdf_CONTEXTBYTES        // 8 bytes  for context to prevent confusion
                                                        // same ecdh shared secret
#define CONTEXT_DEFAULT   "ECDH_KDF"                     // default context (8 chars)

// function we made for a buffer in hexadecimal format
static void hex_print(FILE *f, const char *label, const unsigned char *data, size_t len) {
    fprintf(f, "%s:\n", label);
    for (size_t i = 0; i < len; i++) { //iterating every byte
        fprintf(f, "%02x", data[i]); //morphing into a hexadecimal of the format
                                    // 0X (two characters) in case byte<16
    }
    fprintf(f, "\n");  //print the final product
}

static int parse_hex_key_32_clamped(const char *hex_str, unsigned char out32[SECRETKEY_BYTES]) {
    if (!hex_str) return -1;

    //skipping the "0x"/"0X"
    const char *p = hex_str;
    if (p[0]=='0' && (p[1]=='x' || p[1]=='X')) p += 2;

    size_t len = strlen(p);
    if (len == 0) return -1; //in case the string is empty return -1

    // if number odd then adding a '0' in front of it because we need 
    // double digits
    size_t even_len = (len % 2) ? len + 1 : len;
    char *buf = (char*)malloc(even_len + 1);
    if (!buf) return -1; //in case of memory allocation failure

    if (len % 2){ //if length odd then add '0'
    buf[0] = '0'; 
    memcpy(buf + 1, p, len + 1); 
    }


    else { //if all good, copy string
    memcpy(buf, p, len + 1); 
    }

    even_len = strlen(buf); //buff holds the hex
    size_t bin_len = even_len / 2; //calculate bytes

    // parse in temporary buffer
    unsigned char *tmp = (unsigned char*)calloc(bin_len ? bin_len : 1, 1);
    if (!tmp) { free(buf); return -1; }

    //iterating two characters at a time from string
    for (size_t i=0; i<bin_len; i++) {
        unsigned int v = 0; // integer value we need to save the characters
                            // from hex string after conversion
        if (sscanf(buf + 2*i, "%2x", &v) != 1) {  //read two characters from hex and convert into int
            free(tmp); 
            free(buf);
            return -1; // in case of invalid hex
        }
        tmp[i] = (unsigned char)v; //integer back to byte
    }
    free(buf); //free the buffer

    // right align 32 bytes (left padding with '0')
    // the keys must be of length 32 bytes, in case one isn't right align and left pad
    // into correct form
    memset(out32, 0, SECRETKEY_BYTES);
    if (bin_len >= SECRETKEY_BYTES) {
        memcpy(out32, tmp + (bin_len - SECRETKEY_BYTES), SECRETKEY_BYTES);
    } else {
        memcpy(out32 + (SECRETKEY_BYTES - bin_len), tmp, bin_len);
    }
    free(tmp);

    // X25519 clamping
    out32[0]  &= 248; //setting the lsb of first byte to zero
                    // 248 (11111000 binary) for bits 0,1,2
    out32[31] &= 127; // setting the msb to zero
                    // 127 (01111111 binary) for bit 7
    out32[31] |= 64; // setting the second msb to zero
                    // 64 (01000000 binary) for bit 6

    return 0;
}

int main(int argc, char *argv[]) {
    // libsodium init
    if (sodium_init() < 0) { 
        fprintf(stderr, "libsodium init failed!\n");
        return 1;
    }

    // parameters
    const char *outfile = NULL;
    const char *alice_hex = NULL;
    const char *bob_hex   = NULL;

    char context[KDF_CONTEXT_BYTES + 1];
    memcpy(context, CONTEXT_DEFAULT, KDF_CONTEXT_BYTES);
    context[KDF_CONTEXT_BYTES] = '\0';

    //parsing with getopt
    int opt;
    while ((opt = getopt(argc, argv, "o:a:b:c:h")) != -1) {
        switch (opt) {
            case 'o': outfile = optarg; break; //store output file path
            case 'a': alice_hex = optarg; break; // for alice's key
            case 'b': bob_hex   = optarg; break; // for bob's key
            case 'c': {
                // exactly 8 characters for KDF to work!!!
                size_t L = strlen(optarg);
                if (L != KDF_CONTEXT_BYTES) {
                    fprintf(stderr, "Error: context must be exactly %d chars.\n", KDF_CONTEXT_BYTES);
                    return 1;
                }
                memcpy(context, optarg, KDF_CONTEXT_BYTES);
                context[KDF_CONTEXT_BYTES] = '\0';
            } break;
            case 'h':
            default:
            //correct syntax print
                printf("Usage: %s -o path [-a alice_key] [-b bob_key] [-c context]\n", argv[0]);
                printf(" -o path   Output file (required)\n");
                printf(" -a hex    Alice private key (optional, hex, 0x allowed)\n");
                printf(" -b hex    Bob private key (optional, hex, 0x allowed)\n");
                printf(" -c ctx    KDF context (exactly %d chars, default \"%s\")\n",
                       KDF_CONTEXT_BYTES, CONTEXT_DEFAULT);
                printf(" -h        Help message\n");
                return 0;
        }
    }
    //output file (-o) is needed
    if (!outfile) {
        fprintf(stderr, "Error: Output file is required (-o path)\n");
        return 1;
    }
    //opening output file for writing
    FILE *fout = fopen(outfile, "w");
    if (!fout) { //if error, strerror(errno) provides details why
        fprintf(stderr, "Error opening %s: %s\n", outfile, strerror(errno));
        return 1;
    }

    // 2) keys for Alice/Bob (32-byte scalars & 32-byte public)
    unsigned char a_sk[SECRETKEY_BYTES], a_pk[PUBLICKEY_BYTES];
    unsigned char b_sk[SECRETKEY_BYTES], b_pk[PUBLICKEY_BYTES];

    // Alice SK: load from -a or random + clamp
    if (alice_hex) {
        if (parse_hex_key_32_clamped(alice_hex, a_sk) != 0) {
            fprintf(stderr, "Invalid Alice key\n");
            fclose(fout);
            return 1; // exit in case of invalid key
        }
    } else { // key not provided -> generate a random one
        randombytes_buf(a_sk, SECRETKEY_BYTES);
        a_sk[0]  &= 248; a_sk[31] &= 127; a_sk[31] |= 64; // clamp as explained above
    }
    if (crypto_scalarmult_base(a_pk, a_sk) != 0) {
        fprintf(stderr, "Failed to compute Alice public key\n");
        fclose(fout);
        return 1;
    }

    // Bob SK: from -b or random + clamp (same as Alice)
    if (bob_hex) {
        if (parse_hex_key_32_clamped(bob_hex, b_sk) != 0) {
            fprintf(stderr, "Invalid Bob key\n");
            fclose(fout);
            return 1;
        }
    } else {
        randombytes_buf(b_sk, SECRETKEY_BYTES);
        b_sk[0]  &= 248; b_sk[31] &= 127; b_sk[31] |= 64; // clamp
    }
    if (crypto_scalarmult_base(b_pk, b_sk) != 0) {
        fprintf(stderr, "Failed to compute Bob public key\n");
        fclose(fout);
        return 1;
    }

    // shared secrets: S_A = a*B (a->alice sk, B->bob pk) , S_B = b*A (b->bob sk, A->alice pk)
    unsigned char S_a[SESSIONKEY_BYTES], S_b[SESSIONKEY_BYTES];
    if (crypto_scalarmult(S_a, a_sk, b_pk) != 0 ||
        crypto_scalarmult(S_b, b_sk, a_pk) != 0) {
        fprintf(stderr, "ECDH shared secret calculation failed\n");
        fclose(fout);
        return 1;
    }

    // KDF: 2 keys (Enc/MAC) from shared secret
    unsigned char enc_a[KDF_KEY_LENGTH], mac_a[KDF_KEY_LENGTH];
    unsigned char enc_b[KDF_KEY_LENGTH], mac_b[KDF_KEY_LENGTH];

    if (crypto_kdf_derive_from_key(enc_a, KDF_KEY_LENGTH, 1, context, S_a) != 0 ||
        crypto_kdf_derive_from_key(mac_a, KDF_KEY_LENGTH, 2, context, S_a) != 0 ||
        crypto_kdf_derive_from_key(enc_b, KDF_KEY_LENGTH, 1, context, S_b) != 0 ||
        crypto_kdf_derive_from_key(mac_b, KDF_KEY_LENGTH, 2, context, S_b) != 0) {
        fprintf(stderr, "KDF derivation failed\n");
        fclose(fout);
        return 1;
    }

    // print files
    hex_print(fout, "Alice's Public Key", a_pk, PUBLICKEY_BYTES);
    hex_print(fout, "Bob's Public Key",   b_pk, PUBLICKEY_BYTES);

    hex_print(fout, "Shared Secret (Alice)", S_a, SESSIONKEY_BYTES);
    hex_print(fout, "Shared Secret (Bob)",   S_b, SESSIONKEY_BYTES);

    int secrets_match = (sodium_memcmp(S_a, S_b, SESSIONKEY_BYTES) == 0);
    fprintf(fout, "Shared secrets %s!\n\n", secrets_match ? "match" : "do NOT match");

    hex_print(fout, "Derived Encryption Key (Alice)", enc_a, KDF_KEY_LENGTH);
    hex_print(fout, "Derived Encryption Key (Bob)",   enc_b, KDF_KEY_LENGTH);
    int enc_match = (sodium_memcmp(enc_a, enc_b, KDF_KEY_LENGTH) == 0);
    fprintf(fout, "Encryption keys %s!\n\n", enc_match ? "match" : "do NOT match");

    hex_print(fout, "Derived MAC Key (Alice)", mac_a, KDF_KEY_LENGTH);
    hex_print(fout, "Derived MAC Key (Bob)",   mac_b, KDF_KEY_LENGTH);
    int mac_match = (sodium_memcmp(mac_a, mac_b, KDF_KEY_LENGTH) == 0);
    fprintf(fout, "MAC keys %s!\n", mac_match ? "match" : "do NOT match");

    fclose(fout);
    return 0;
}