
2o PROJECT 

--CRYPTEX: ECDH & RSA IN C

|ΔΗΜΗΤΡΑ ΡΑΠΤΟΠΟΥΛΟΥ 2022030132|
|ΕΛΙΖΑ ΠΟΛΥΖΟΥ 2022030132      |


Περιγραφή Project

Στοχος του project να υλοποιήσει δύο βασικούς μηχανισμούς ασφαλείας, το ECDH (Elliptic Curve Diffie–Hellman)
για ασφαλή ανταλλαγή κοινών μυστικών μέσω της καμπύλης CURVE25519 και RSA για κρυπτογράφηση,αποκρυπτογράφηση και ψηφιακές υπογραφές.

Το project αυτο υλοποιήθηκε σε κώδικα C με χρηση
|libsodium ,καμπύλη X25519 & SHA-256|
|GMP (libgmp) για πράξεις ακέραιων μεγάλου μεγέθους στην RSA|

ΠΡΟΑΠΑΙΤΟΥΜΕΝΕΣ ΒΙΒΛΙΟΘΗΚΕΣ, ΕΡΓΑΛΕΙΑ ΚΑΙ ΑΡΧΕΙΑ 

sudo apt install gcc make libgmp-dev libsodium-dev // βιβλιοθηκες,εργαλεια

Makefile
ecdh_assign_2.c
rsa_assign_2.c
rsa.c               //αρχεια project
utils.c
utils.h
rsa.h

ecdh_assign_2  //εκτελεσιμα που παράγονται
rsa_assign_2

Για build των δυο εργαλειων χρησιμοποιησαμε την εντολη make ενω για τον καθαρισμο προηγουμεων αρχειων το make clean


ECDH Tool 

Το εργαλείο ecdh_assign_2 προσομοιώνει Alice/Bob:

1.Δημιουργεί κλειδιά (τυχαία ή από δοθέντα hex private keys),

2.Υπολογίζει κοινό μυστικό με crypto_scalarmult,

3.Παράγει δύο ανεξάρτητα κλειδιά με KDF (crypto_kdf_derive_from_key):

     Encryption Key (subkey id = 1),

     MAC Key (subkey id = 2).


-- Το context του KDF πρέπει να είναι ακριβώς 8 χαρακτήρες (όριο της libsodium).

Χρήση
 ./ecdh_assign_2 -o <output_file> [-a <alice_sk>] [-b <bob_sk>] [-c <context>]

Επιλογές:

-o <path>: αρχείο εξόδου (υποχρεωτικό)

-a <hex>: ιδιωτικό κλειδί Alice (προαιρετικό, hex – δέχεται και 0x prefix)

-b <hex>: ιδιωτικό κλειδί Bob (προαιρετικό, hex)

-c <8-chars>: context για το KDF (προεπιλογή: ECDH_KDF)


Παραδειγμα : 

./ecdh_assign_2 -o ecdh_results.txt -a 0x1A2B3C -b 0xDEADCAFE -c CTX00001

Οπου περιμενουμε τα παραγωγα κλειδια να ταυτίζονται μόνο αν το context είναι ίδιο.


RSA Tool 

Το εργαλείο rsa_assign_2 υλοποιεί:

Keypair generation (δημιουργία public_<bits>.key, private_<bits>.key),

Encryption / Decryption (με n,e / n,d αντίστοιχα),

Sign / Verify (SHA-256 + modular exponentiation),

Performance analysis για 1024/2048/4096 bits (χρόνος/μνήμη ανά πράξη)


Λειτουργία	Μαθηματικός τύπος	Κλειδί
Encryption	C = M^e mod n	Public (n, e)
Decryption	M = C^d mod n	Private (n, d)
Signing	S = H^d mod n	Private (n, d)
Verification	H' = S^e mod n	Public (n, e)

  -g <len>   Generate RSA key pair (1024 / 2048 / 4096)
  -e         Encrypt file
  -d         Decrypt file
  -s         Sign file
  -v <sig>   Verify signature file
  -a <file>  Run performance analysis and write report
  -i <path>  Input path
  -o <path>  Output path
  -k <key>   Key file (public/private)
  -h         Show help

Για τη δημιουργία κλειδιών : 
./rsa_assign_2 -g 2048
# Παράγεται public_2048.key (n,e) και private_2048.key (n,d)

Για κρυπτογράφηση,αποκρυπτογράφηση:
./rsa_assign_2 -e -i msg.txt -o msg.enc -k public_2048.key
./rsa_assign_2 -d -i msg.enc -o msg.out -k private_2048.key
diff -s msg.txt msg.out   
#πρέπει να εμφανίζονται identical

Για Ψηφιακή Υπογραφή και Έλεγχος:
./rsa_assign_2 -s -i doc.pdf -o doc.sig -k private_2048.key
./rsa_assign_2 -v doc.sig -i doc.pdf -k public_2048.key
# Output:Signature is VALID / INVALID

Μετρήσεις :
./rsa_assign_2 -a analysis.txt
# ανά bit-length: χρόνους για Enc/Dec/Sign/Verifυ+Peak memory

