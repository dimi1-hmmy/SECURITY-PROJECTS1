#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/resource.h>
#include <gmp.h>
#include <sodium.h>

#include "rsa.h"
#include "utils.h"

//helper functions for timing and memory
// return precise timestamp (in seconds) for benchmarking 
static double now_seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + (ts.tv_nsec / 1e9);
}

// return peak memory used for this process (in KB) 
static long peak_memory_kb(void) {
    struct rusage usage;
    if (getrusage(RUSAGE_SELF, &usage) == 0) {
#ifdef __APPLE__
        return usage.ru_maxrss / 1024; // macOS returns bytes
#else
        return usage.ru_maxrss;        // Linux returns kilobytes
#endif
    }
    perror("getrusage");
    return 0;
}

//key generation

void rsa_generate_keys(const char *length_str) {
    int bits = atoi(length_str);
    // only allow 1024, 2048, or 4096 bits
    if (bits != 1024 && bits != 2048 && bits != 4096) {
        fprintf(stderr, "Error: Supported key sizes are 1024, 2048, or 4096 bits.\n");
        return;
    }

    printf("Generating RSA key pair (%d bits)...\n", bits);

    int half_bits = bits / 2;

    // init gmp big ints
    mpz_t p, q, n, lambda, e, d, p1, q1, gcd;
    mpz_inits(p, q, n, lambda, e, d, p1, q1, gcd, NULL);

    // init random state
    gmp_randstate_t rnd;
    gmp_randinit_default(rnd);
    gmp_randseed_ui(rnd, (unsigned long)time(NULL));

    // get different prime numbers p and q
    do {
        mpz_urandomb(p, rnd, half_bits);
        mpz_nextprime(p, p);
        mpz_urandomb(q, rnd, half_bits);
        mpz_nextprime(q, q);
    } while (mpz_cmp(p, q) == 0);

    // get modulus n = p * q
    mpz_mul(n, p, q);

    // compute λ(n) = (p−1)(q−1)
    mpz_sub_ui(p1, p, 1);
    mpz_sub_ui(q1, q, 1);
    mpz_mul(lambda, p1, q1);

    //public exponent e = 65537
    mpz_set_ui(e, 65537);

    //ensuring gcd(e, λ) == 1
    mpz_gcd(gcd, e, lambda);
    if (mpz_cmp_ui(gcd, 1) != 0) {
        fprintf(stderr, "Invalid e, gcd(e, λ) != 1. Try again.\n");
        goto cleanup;
    }

    //compute private exponent 
    if (mpz_invert(d, e, lambda) == 0) {
        fprintf(stderr, "Error: could not compute modular inverse.\n");
        goto cleanup;
    }

    // save keys to files
    char pub_file[64], priv_file[64];
    sprintf(pub_file, "public_%d.key", bits);
    sprintf(priv_file, "private_%d.key", bits);

    // write keys to files
    FILE *fpub = fopen(pub_file, "w");
    FILE *fpriv = fopen(priv_file, "w");
    if (!fpub || !fpriv) { //in case of error
        fprintf(stderr, "Error writing key files.\n");
        goto cleanup;
    }

    // public key: (n, e)
    write_mpz_to_file(fpub, "n", n);
    write_mpz_to_file(fpub, "e", e);
    fclose(fpub);

    //private key: (n, d)
    write_mpz_to_file(fpriv, "n", n);
    write_mpz_to_file(fpriv, "d", d);
    fclose(fpriv);

    printf("Keys successfully saved to %s and %s\n", pub_file, priv_file);

cleanup:
    mpz_clears(p, q, n, lambda, e, d, p1, q1, gcd, NULL);
    gmp_randclear(rnd);
}

//RSA encryption

void rsa_encrypt(const char *in_file, const char *out_file, const char *key_file) {
    mpz_t n, e, M, C;
    mpz_inits(n, e, M, C, NULL);

    FILE *kf = fopen(key_file, "r"); //load public key
    if (!kf) {
        fprintf(stderr, "Cannot open key file: %s\n", key_file);
        goto cleanup;
    }
    if (!load_key_component(n, "n", kf) || !load_key_component(e, "e", kf)) {
        fclose(kf);
        goto cleanup;
    }
    fclose(kf); //close file stream

    // read input file to memory
    FILE *in = fopen(in_file, "rb");
    if (!in) {
        fprintf(stderr, "Cannot open input file: %s\n", in_file);
        goto cleanup;
    }

    fseek(in, 0, SEEK_END);
    size_t size = ftell(in);
    fseek(in, 0, SEEK_SET);

    unsigned char *buf = malloc(size);
    if (!buf) {
        fprintf(stderr, "Memory allocation failed.\n");
        fclose(in);
        goto cleanup;
    }

    fread(buf, 1, size, in);
    fclose(in);

    mpz_import(M, size, 1, 1, 1, 0, buf); // turn data into number
    free(buf);

    // C = M^e mod n
    mpz_powm(C, M, e, n);

    FILE *out = fopen(out_file, "w"); // write ciphertext
    if (!out) {
        fprintf(stderr, "Cannot open output file: %s\n", out_file);
        goto cleanup;
    }
    mpz_out_str(out, 16, C);
    fclose(out);

    printf("Encrypted successfully → %s\n", out_file);

cleanup:
    mpz_clears(n, e, M, C, NULL);
}

//RSA decryption

void rsa_decrypt(const char *in_file, const char *out_file, const char *key_file) {
    mpz_t n, d, M, C;
    mpz_inits(n, d, M, C, NULL);

    FILE *kf = fopen(key_file, "r"); //load private key
    if (!kf) {
        fprintf(stderr, "Cannot open key file: %s\n", key_file);
        goto cleanup;
    }
    if (!load_key_component(n, "n", kf) || !load_key_component(d, "d", kf)) {
        fclose(kf);
        goto cleanup;
    }
    fclose(kf);

    FILE *in = fopen(in_file, "r"); // read ciphertext
    if (!in || mpz_inp_str(C, in, 16) == 0) {
        fprintf(stderr, "Failed to read ciphertext.\n");
        if (in) fclose(in);
        goto cleanup;
    }
    fclose(in);

    // M = C^d mod n
    mpz_powm(M, C, d, n);

    FILE *out = fopen(out_file, "wb"); //back to bytes
    if (!out) {
        fprintf(stderr, "Cannot open output file: %s\n", out_file);
        goto cleanup;
    }

    size_t written;
    unsigned char *buf = mpz_export(NULL, &written, 1, 1, 1, 0, M);
    fwrite(buf, 1, written, out);
    fclose(out);
    free(buf);

    printf("Decrypted successfully → %s\n", out_file);

cleanup:
    mpz_clears(n, d, M, C, NULL);
}


 //RSA signing and verification
 
void rsa_sign(const char *in_file, const char *sig_file, const char *key_file) {
    mpz_t n, d, hash, sig;
    mpz_inits(n, d, hash, sig, NULL);

    FILE *kf = fopen(key_file, "r");  // load private key
    if (!kf || !load_key_component(n, "n", kf) || !load_key_component(d, "d", kf)) {
        fprintf(stderr, "Error reading private key.\n");
        if (kf) fclose(kf);
        goto cleanup;
    }
    fclose(kf);

    unsigned char digest[crypto_hash_sha256_BYTES]; // hash file
    if (!compute_sha256(in_file, digest)) {
        fprintf(stderr, "Error hashing file.\n");
        goto cleanup;
    }
    //convert hash(digest) into large int
    mpz_import(hash, sizeof(digest), 1, 1, 1, 0, digest);
    // sign = hash^d mod n
    mpz_powm(sig, hash, d, n);

    FILE *sf = fopen(sig_file, "w"); // save signature
    if (!sf) {
        fprintf(stderr, "Cannot open signature file.\n");
        goto cleanup;
    }
    mpz_out_str(sf, 16, sig); //export final sig as hex string
    fclose(sf); 

    printf("Signature created → %s\n", sig_file);

cleanup:
    mpz_clears(n, d, hash, sig, NULL);
}

void rsa_verify(const char *in_file, const char *sig_file, const char *key_file) {
    mpz_t n, e, sig, recovered;
    mpz_inits(n, e, sig, recovered, NULL);

    FILE *kf = fopen(key_file, "r");
    if (!kf || !load_key_component(n, "n", kf) || !load_key_component(e, "e", kf)) {
        fprintf(stderr, "Error reading public key.\n");
        if (kf) fclose(kf);
        goto cleanup;
    }
    fclose(kf);

    unsigned char expected[crypto_hash_sha256_BYTES]; // hash file to compare
    if (!compute_sha256(in_file, expected)) {
        fprintf(stderr, "Error computing original hash.\n");
        goto cleanup;
    }

    FILE *sf = fopen(sig_file, "r");
    if (!sf || mpz_inp_str(sig, sf, 16) == 0) {
        fprintf(stderr, "Error reading signature.\n");
        if (sf) fclose(sf);
        goto cleanup;
    }
    fclose(sf);

    mpz_powm(recovered, sig, e, n); // recover hash: sig^e mod n

    unsigned char recovered_padded[crypto_hash_sha256_BYTES] = {0};
    size_t sz;
    unsigned char *tmp = mpz_export(NULL, &sz, 1, 1, 1, 0, recovered);
    if (sz <= crypto_hash_sha256_BYTES)
        memcpy(recovered_padded + (crypto_hash_sha256_BYTES - sz), tmp, sz);
    free(tmp);

    //compare the hash expected and the one recovered
    if (sodium_memcmp(expected, recovered_padded, crypto_hash_sha256_BYTES) == 0)
        printf("Signature is VALID\n");
    else
        printf("Signature is INVALID\n");

cleanup:
    mpz_clears(n, e, sig, recovered, NULL);
}

//performance analysis (Encryption / Decryption / Signing / Verification)


void rsa_analyze(const char *outfile) {
    FILE *out = fopen(outfile, "w");
    if (!out) {
        fprintf(stderr, "Cannot open output file: %s\n", outfile);
        return;
    }

    int sizes[] = {1024, 2048, 4096}; //key sizes
    int count = sizeof(sizes) / sizeof(sizes[0]); //number of sizes in array.

    mpz_t msg, hash, cipher, msg2, sig, hash2;
    mpz_inits(msg, hash, cipher, msg2, sig, hash2, NULL);

    unsigned char data[256]; //fixed 256 bit hash
    for (int i = 0; i < 256; i++) data[i] = i;
    crypto_hash_sha256((unsigned char *)data, data, sizeof(data));
    mpz_import(msg, sizeof(data), 1, 1, 1, 0, data);

    printf("Running RSA performance benchmarks...\n"); //start benchmark

    for (int i = 0; i < count; i++) {
        int bits = sizes[i];
        fprintf(out, "Key Length: %d bits\n", bits);

        mpz_t n, e, d;
        mpz_inits(n, e, d, NULL);

        mpz_t p, q, phi, p1, q1;
        mpz_inits(p, q, phi, p1, q1, NULL);
        gmp_randstate_t rnd;
        gmp_randinit_default(rnd);
        gmp_randseed_ui(rnd, time(NULL));

        mpz_urandomb(p, rnd, bits / 2);
        mpz_nextprime(p, p);
        mpz_urandomb(q, rnd, bits / 2);
        mpz_nextprime(q, q);
        mpz_mul(n, p, q);
        mpz_sub_ui(p1, p, 1);
        mpz_sub_ui(q1, q, 1);
        mpz_mul(phi, p1, q1);
        mpz_set_ui(e, 65537);
        mpz_invert(d, e, phi);
        gmp_randclear(rnd);
        mpz_clears(p, q, phi, p1, q1, NULL);

        // define how many loops for each test (depends on key size)
        int fast_loops = (bits == 4096) ? 20000 : 50000;
        int slow_loops = (bits == 4096) ? 200 : 500;

        double start, end;
        long mem;

        //encryption
        start = now_seconds();
        for (int j = 0; j < fast_loops; j++)
            mpz_powm(cipher, msg, e, n);
        end = now_seconds();
        mem = peak_memory_kb();
        fprintf(out, "Encryption Time: %.6fs\n", (end - start) / fast_loops);
        fprintf(out, "Peak Memory Usage (Encryption): %ld KB\n", mem);

        //decryption
        start = now_seconds();
        for (int j = 0; j < slow_loops; j++)
            mpz_powm(msg2, cipher, d, n);
        end = now_seconds();
        mem = peak_memory_kb();
        fprintf(out, "Decryption Time: %.6fs\n", (end - start) / slow_loops);
        fprintf(out, "Peak Memory Usage (Decryption): %ld KB\n", mem);

        //signing
        start = now_seconds();
        for (int j = 0; j < slow_loops; j++)
            mpz_powm(sig, hash, d, n);
        end = now_seconds();
        mem = peak_memory_kb();
        fprintf(out, "Signing Time: %.6fs\n", (end - start) / slow_loops);
        fprintf(out, "Peak Memory Usage (Signing): %ld KB\n", mem);

        //verification
        start = now_seconds();
        for (int j = 0; j < fast_loops; j++)
            mpz_powm(hash2, sig, e, n);
        end = now_seconds();
        mem = peak_memory_kb();
        fprintf(out, "Verification Time: %.6fs\n", (end - start) / fast_loops);
        fprintf(out, "Peak Memory Usage (Verification): %ld KB\n", mem);

        if (i < count - 1) fprintf(out, "\n");
        printf("Completed %d-bit RSA test.\n", bits);

        mpz_clears(n, e, d, NULL);
    }

    fclose(out);
    mpz_clears(msg, hash, cipher, msg2, sig, hash2, NULL);
    printf("Benchmark results saved to %s\n", outfile);
}
