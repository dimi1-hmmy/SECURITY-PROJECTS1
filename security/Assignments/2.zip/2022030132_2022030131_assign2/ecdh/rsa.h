#ifndef RSA_H
#define RSA_H

void rsa_generate_keys(const char *bits_str);
void rsa_encrypt(const char *in, const char *out, const char *key);
void rsa_decrypt(const char *in, const char *out, const char *key);
void rsa_sign(const char *in, const char *sig, const char *key);
void rsa_verify(const char *in, const char *sig, const char *key);
void rsa_analyze(const char *out);

#endif


