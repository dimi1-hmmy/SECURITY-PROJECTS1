#include "utils.h"
#include <string.h>
#include <stdlib.h>

// trim trailing \n/\r 
static void trim_eol(char *s) {
    size_t n = strlen(s);
    while (n && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = '\0';
}

//signature must match utils.h 
bool load_key_component(mpz_t out, const char *label, FILE *fp) {
    if (!fp || !label) 
    return false;

    char line[8192];

    //read label line (first line of file)
    if (!fgets(line, sizeof line, fp)) 
    return false;
    trim_eol(line);
    if (strcmp(line, label) != 0) 
    return false;

    // read hex line
    if (!fgets(line, sizeof line, fp)) 
    return false;
    trim_eol(line);

    //base 16
    //convert the hex string into gmp large int
    if (mpz_set_str(out, line, 16) != 0) 
    return false;

    return true;
}

//signature must match utils.h exactly (array param)
//computing the sha256 
bool compute_sha256(const char *path, unsigned char out[crypto_hash_sha256_BYTES]) {
    if (!path || !out) 
    return false;

    FILE *f = fopen(path, "rb");
    if (!f) 
    return false;

    unsigned char buf[8192];
    crypto_hash_sha256_state st;
    crypto_hash_sha256_init(&st);

    //read the file (streaming hash computation)
    for (;;) {
        size_t n = fread(buf, 1, sizeof buf, f);
        if (n) crypto_hash_sha256_update(&st, buf, n);
        if (n < sizeof buf) break; /* EOF */
    }

    crypto_hash_sha256_final(&st, out);
    fclose(f);
    return true;
}

// const mpz_t to match header
void write_mpz_to_file(FILE *fp, const char *label, const mpz_t x) {
    if (!fp || !label) 
    return;
    fprintf(fp, "%s\n", label);
    gmp_fprintf(fp, "%ZX\n", x);
}
