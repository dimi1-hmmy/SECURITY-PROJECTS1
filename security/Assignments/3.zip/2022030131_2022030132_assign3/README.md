Assignment 3 – Access Audit System (2025)

RAPTOPOULOU DIMITRA - 2022030132
ELIZA POLYZOU-2022030131

Το παρόν README περιγράφει την υλοποίηση ενός πλήρους συστήματος ελέγχου πρόσβασης σε αρχεία, αποτελούμενο από:
μία LD_PRELOAD βιβλιοθήκη που παρεμβάλλεται σε βασικές συναρτήσεις αρχείων και καταγράφει δραστηριότητα
ένα εργαλείο επεξεργασίας log που εντοπίζει ύποπτη ή μη εξουσιοδοτημένη συμπεριφορά
ένα test program που παράγει ελεγχόμενες λειτουργίες για να επιβεβαιωθεί η ορθότητα του συστήματος
Το έγγραφο λειτουργεί ως συνολική αναφορά: εξήγηση αρχείων, μηχανισμός, format του log, τρόπος χρήσης monitor, compilation, παραδείγματα και αναμενόμενη συμπεριφορά.

Περιεχόμενα Αρχείων
1. audit_logger.c
Shared library (audit_logger.so) που κάνει interception στις:
fopen
fwrite
fclose
και γράφει εγγραφές στο access_audit.log.
2. audit_monitor.c
Αναλυτής log με δύο modes:

-s → Εμφάνιση χρηστών που είχαν αποτυχημένες προσβάσεις (denied = 1)

-i <filename> → Μετράει πόσες τροποποιήσεις (writes) έγιναν σε ένα αρχείο και από ποιον χρήστη

3. test_audit.c
Πρόγραμμα δοκιμής που κάνει controlled file operations (create/open/write/close + denied).
Χρησιμοποιείται για επαλήθευση της βιβλιοθήκης.
4. Makefile
Αυτοματοποιεί το build των παραπάνω και παρέχει target για εκτέλεση με LD_PRELOAD.
Απαιτήσεις για Εκτέλεση
Linux με glibc
GCC
OpenSSL libraries (για SHA-256)
sudo apt install libssl-dev
Τρόπος Μεταγλώττισης (Build)
Χρησιμοποιώντας το Makefile:
make
Για καθαρισμό:

make clean

Τρόπος Εκτέλεσης
1. Παραγωγή Log μέσω LD_PRELOAD
LD_PRELOAD=./audit_logger.so ./test_audit
ή για παρακολούθηση οποιουδήποτε binary:
LD_PRELOAD=./audit_logger.so /usr/bin/touch file.txt
Μετά τη χρήση, δημιουργείται το αρχείο:
access_audit.log

2. Εκτέλεση Monitor (χωρίς LD_PRELOAD!)
./audit_monitor -s
./audit_monitor -i demo_file.txt

3. Προβολή Log
cat access_audit.log

Log Format – Αναλυτική Περιγραφή

Κάθε γραμμή έχει τη μορφή:
uid|pid|filepath|date|time|operation|denied|hash

Αναλυτικά:

Πεδίο	Τι περιέχει
uid	User ID της διεργασίας
pid	Process ID
filepath	Path του αρχείου όπως δόθηκε στο fopen
date	UTC ημερομηνία σε epoch seconds
time	UTC ώρα (επίσης epoch seconds)
operation	0=create, 1=open, 2=write, 3=close
denied	1=αποτυχία, 0=επιτυχία
hash	SHA-256 του αρχείου ή "-"
Ορισμοί ενεργειών

Create (0): Άνοιγμα αρχείου για εγγραφή που δεν υπήρχε πριν

Open (1): Επιτυχές άνοιγμα υπάρχοντος αρχείου

Write (2): Επιτυχής εγγραφή μέσω fwrite

Close (3): Κλείσιμο μέσω fclose

Η τιμή denied=1 καταγράφεται όταν η underlying libc κλήση αποτύχει (NULL από fopen, 0 bytes από fwrite, λάθος από fclose κλπ).
Audit Monitor – Αναλυτική Λειτουργία
1. Επιλογή -s (Suspicious Users)
Εντοπίζει κάθε χρήστη και καταγράφει ποια μοναδικά αρχεία απέτυχε να προσπελάσει.
Παράδειγμα εξόδου:

Unauthorized Accesses:
UID 1000: does_not_exist.txt /

2. Επιλογή -i <filename>

Υπολογίζει πόσες τροποποιήσεις (writes) έγιναν στο συγκεκριμένο αρχείο.
Υποστηρίζει:
απόλυτο path
σχετικό path
ταίριασμα με basename

Παράδειγμα:

./audit_monitor -i demo_file.txt


Έξοδος:

File modifications for 'demo_file.txt':
UID 1000 -> 2 modification(s)
Test Program – Περιγραφή

Το test_audit.c εκτελεί:

Δημιουργία αρχείου
Άνοιγμα σε append mode
Εγγραφές
Κλείσιμο
Δύο επίτηδες αποτυχημένες ενέργειες (denied)
Παράγει έτσι ένα πλήρες σετ logs για έλεγχο της βιβλιοθήκης.
Παράδειγμα End-to-End Εκτέλεσης
make clean
make
LD_PRELOAD=./audit_logger.so ./test_audit
./audit_monitor -s
./audit_monitor -i test1.txt

Troubleshooting
Πρόβλημα	Λύση
Δεν δημιουργείται το access_audit.log	Έτρεξες χωρίς LD_PRELOAD
Το audit_monitor δεν εμφανίζει τίποτα	Άδειο log ή λάθος path στο -i
Crash στο logger	Λείπει το -ldl ή το -lcrypto στο Makefile
Άδειο hash	Το αρχείο δεν υπήρχε ή δεν μπορούσε να διαβαστεί
Checklist για Παράδοση

audit_logger.c
audit_monitor.c
test_audit.c
audit_logger.so
Makefile
access_audit.log (μετά την εκτέλεση test)
README (το παρόν)