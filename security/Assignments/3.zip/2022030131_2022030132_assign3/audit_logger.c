#define _GNU_SOURCE

#include <time.h>
#include <stdio.h>      //for typedef FILE and dprintf prototype
#include <dlfcn.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <openssl/evp.h> //install the required package

#include <errno.h>
#include <sys/types.h>
#include <fcntl.h>
#include <limits.h>

/* log file */
static const char *LOG_FILE = "access_audit.log";

/*ld_preload library wraps fopen / fwrite / fclose
and logs every file access along with SHA-256 fingerprint.
access_kind: 0=create, 1=open, 2=write, 3=close
denied: 1=libc call failed, 0=success
*/

/* helper that convert bytes to hex string*/
static void bytes_to_hex(const unsigned char *in, size_t len,
                         char *out /*size >= 2*len+1 */) {
    static const char hex_digits[] = "0123456789abcdef";
    for (size_t i = 0; i < len; ++i) {
        out[2*i]     = hex_digits[(in[i] >> 4) & 0xF];
        out[2*i + 1] = hex_digits[in[i] & 0xF];
    }
    out[2*len] = '\0';//add string terminator
}

/*helper, SHA-256 with open/read (not stdio)*/
static int sha256_of_path(const char *path, char out_hex[65]) {
    int fd = open(path, O_RDONLY);//open file directly from syscall
    if (fd < 0) {
        strcpy(out_hex, "-");
        return -1;
    }

    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (!ctx) {
        close(fd);
        strcpy(out_hex, "-");
        return -1;
    }
    //initialize SHA-256 hashing
    if (EVP_DigestInit_ex(ctx, EVP_sha256(), NULL) != 1) {
        EVP_MD_CTX_free(ctx);
        close(fd);
        strcpy(out_hex, "-");
        return -1;
    }

    unsigned char buf[4096];
    unsigned char digest[EVP_MAX_MD_SIZE];
    unsigned int digest_len = 0;
    //read the entire file and feed into SHA-256
    for (;;) {
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n < 0) {
            if (errno == EINTR) continue;
            EVP_MD_CTX_free(ctx);
            close(fd);
            strcpy(out_hex, "-");
            return -1;
        }
        if (n == 0) break;
        if (EVP_DigestUpdate(ctx, buf, (size_t)n) != 1) {
            EVP_MD_CTX_free(ctx);
            close(fd);
            strcpy(out_hex, "-");
            return -1;
        }
    }

    if (EVP_DigestFinal_ex(ctx, digest, &digest_len) != 1) {
        EVP_MD_CTX_free(ctx);
        close(fd);
        strcpy(out_hex, "-");
        return -1;
    }

    EVP_MD_CTX_free(ctx);
    close(fd);

    bytes_to_hex(digest, digest_len, out_hex);
    return 0;
}

/* helper that takes path from FILE*via /proc/self/fd */
static int path_from_FILE(FILE *fp, char *buf, size_t bufsz) {
    int fd = fileno(fp);
    if (fd < 0) return -1;

    char linkpath[64];
    snprintf(linkpath, sizeof(linkpath), "/proc/self/fd/%d", fd);

    ssize_t r = readlink(linkpath, buf, bufsz - 1);
    if (r < 0) return -1;
    buf[r] = '\0';
    return 0;
}

/*helper that checks if the FILE* exists before fopen*/
static int path_existed_before(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0) return 1;//file exists
    if (errno == ENOENT)      return 0;//file does not exist
    /*uncertain case:assume file existed to avoid false "create" events*/
    return 1;
}

/* make an absolute path using realpath() if possible */
static void make_absolute(const char *input, char *out, size_t outsz) {
    if (!input || !*input) {
        snprintf(out, outsz, "-");
        return;
    }
    char resolved[PATH_MAX];
    if (realpath(input, resolved) != NULL) {
        snprintf(out, outsz, "%s", resolved);
    } else {
        snprintf(out, outsz, "%s", input);
    }
}

/* logging with guard to prevend recursion */
static __thread int inside_logger = 0;

static void log_event(int access_kind,
                      int denied,
                      const char *filepath,
                      const char *hash_hex)
{
    if (inside_logger) return;//avoid recursion
    inside_logger = 1;

    int log_fd = open(LOG_FILE, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (log_fd >= 0) {
        time_t now = time(NULL);
        uid_t uid = getuid();
        pid_t pid = getpid();

        /* UTC date + time */
        struct tm tm_utc;
        gmtime_r(&now, &tm_utc);

        char date_buf[16];
        char time_buf[16];

        strftime(date_buf, sizeof(date_buf), "%Y-%m-%d", &tm_utc);
        strftime(time_buf, sizeof(time_buf), "%H:%M:%S", &tm_utc);

        /* Format required by assignment:
           UID|PID|FILENAME|DATE|TIME|OP|DENIED|HASH
        */
        dprintf(log_fd, "%d|%d|%s|%s|%s|%d|%d|%s\n",
                (int)uid,
                (int)pid,
                (filepath && *filepath) ? filepath : "-",
                date_buf,
                time_buf,
                access_kind,
                denied,
                (hash_hex && *hash_hex) ? hash_hex : "-");

        close(log_fd);
    }

    inside_logger = 0;
}


/* ====================== Interposed functions ====================== */

FILE *
fopen(const char *path, const char *mode)
{
    /* check existence BEFORE calling original fopen */
    int existed = path ? path_existed_before(path) : 1;

    FILE *original_fopen_ret;
    FILE *(*original_fopen)(const char*, const char*);

    /* call the original fopen function */
    original_fopen = dlsym(RTLD_NEXT, "fopen");
    original_fopen_ret = (*original_fopen)(path, mode);

    /* add your code here */
    /* ... */
    /* ... */
    /* ... */
    /* ... */

    int access_kind = 1;  /* default: open */
    int denied = (original_fopen_ret == NULL) ? 1 : 0;

    if (path && !existed && original_fopen_ret != NULL) {
        /*decide create/open first — stat() must run before the actual fopen*/
        if (strchr(mode, 'w') || strchr(mode, 'a') ||
            strchr(mode, 'x') || strchr(mode, '+')) {
            access_kind = 0; /* create */
        }
    }

    char abs_path[PATH_MAX];
    make_absolute(path ? path : "-", abs_path, sizeof(abs_path));

    char hash_hex[65];
    if (path && !denied) {
        sha256_of_path(abs_path, hash_hex);
    } else {
        strcpy(hash_hex, "-");
    }

    log_event(access_kind, denied, abs_path, hash_hex);

    return original_fopen_ret;
}


size_t
fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{

    size_t original_fwrite_ret;
    size_t (*original_fwrite)(const void*, size_t, size_t, FILE*);

    /* call the original fwrite function */
    original_fwrite = dlsym(RTLD_NEXT, "fwrite");
    original_fwrite_ret = (*original_fwrite)(ptr, size, nmemb, stream);


    /* add your code here */
    /* ... */
    /* ... */
    /* ... */
    /* ... */

    char pathbuf[PATH_MAX];
    char hash_hex[65];
    int denied = 0;

    if (size * nmemb > 0 && original_fwrite_ret == 0) {
        denied = 1;
    }

    if (path_from_FILE(stream, pathbuf, sizeof(pathbuf)) == 0) {
        if (sha256_of_path(pathbuf, hash_hex) != 0) {
            strcpy(hash_hex, "-");
        }
        log_event(2, denied, pathbuf, hash_hex);
    } else {
        log_event(2, denied, "-", "-");
    }

    return original_fwrite_ret;
}


int
fclose(FILE *stream)
{

    int original_fclose_ret;
    int (*original_fclose)(FILE*);

    char pathbuf[PATH_MAX];
    int have_path = (path_from_FILE(stream, pathbuf, sizeof(pathbuf)) == 0);

    /* call the original fclose function */
    original_fclose = dlsym(RTLD_NEXT, "fclose");
    original_fclose_ret = (*original_fclose)(stream);


    /* add your code here */
    /* ... */
    /* ... */
    /* ... */

    int denied = (original_fclose_ret != 0) ? 1 : 0;

    char hash_hex[65];
    if (have_path && !denied) {
        if (sha256_of_path(pathbuf, hash_hex) != 0) {
            strcpy(hash_hex, "-");
        }
        log_event(3, denied, pathbuf, hash_hex);
    } else {
        log_event(3, denied, "-", "-");
    }

    return original_fclose_ret;
}
