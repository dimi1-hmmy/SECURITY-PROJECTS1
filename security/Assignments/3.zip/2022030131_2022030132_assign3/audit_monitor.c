#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define LOGFILE_NAME       "access_audit.log"
#define MAX_BUFFER_SIZE    1024
#define MAX_USER_ENTRIES   2048
#define MAX_FILES_PER_UID  256

/* οne log record:
 * uid|pid|filename|date|time|operation|denied|hash
 */
struct audit_record {
    int   user_id;        /* uid */
    pid_t proc_id;        /* pid */
    char *filepath;       /* filename (may include path) */
    time_t log_date;      /* epoch seconds */
    time_t log_time;      /* epoch seconds */
    int   op_type;        /* 0=create,1=open,2=write,3=close */
    int   is_denied;      /* 0/1 */
    char *hash_value;     /* sha256 or "-" */
};

/*print CLI usage */
static void show_usage(void) {
    printf("Usage: audit_monitor [-s] [-i <filename>] [-h]\n");
    printf("  -s               List unauthorized accesses per user (denied = 1)\n");
    printf("  -i <filename>    List users who modified the given file and how many times\n");
    printf("  -h               Show this help\n");
}

/*parse one log line into struct audit_record.
 *returns NULL on malformed line or allocation failure.
 */
static struct audit_record *parse_record(char *line) {
    struct audit_record *rec = malloc(sizeof(*rec));
    if (!rec) return NULL;
    memset(rec, 0, sizeof(*rec));

    char *saveptr = NULL;
    char *token   = NULL;
    int   field   = 0;

    /* Format: uid|pid|file|date|time|access|denied|fingerprint */
    token = strtok_r(line, "|\n", &saveptr);
    while (token) {
        switch (field) {
            case 0: rec->user_id   = atoi(token);        break;
            case 1: rec->proc_id   = (pid_t)atoi(token); break;
            case 2: rec->filepath  = strdup(token);      break;
            case 3: rec->log_date  = (time_t)atol(token);break;
            case 4: rec->log_time  = (time_t)atol(token);break;
            case 5: rec->op_type   = atoi(token);        break;
            case 6: rec->is_denied = atoi(token);        break;
            case 7: rec->hash_value = strdup(token);     break;
            default: break;
        }
        field++;
        token = strtok_r(NULL, "|\n", &saveptr);
    }

    /*not enough fields, invalid line */
    if (field < 8) {
        if (rec->filepath)   free(rec->filepath);
        if (rec->hash_value) free(rec->hash_value);
        free(rec);
        return NULL;
    }

    return rec;
}

/*free one parsed record*/
static void free_record(struct audit_record *rec) {
    if (!rec) return;
    free(rec->filepath);
    free(rec->hash_value);
    free(rec);
}

/* helpers*/

/*-s, distinct denied files per user */
struct user_access_list {
    int   uid;
    int   file_count;
    char *files[MAX_FILES_PER_UID];
};

/*find existing user entry or create a new one*/
static struct user_access_list *find_or_add_user(struct user_access_list *array,
                                                 int *count,
                                                 int uid)
{
    for (int i = 0; i < *count; ++i) {
        if (array[i].uid == uid) {
            return &array[i];
        }
    }

    if (*count >= MAX_USER_ENTRIES) {
        return NULL;
    }

    array[*count].uid        = uid;
    array[*count].file_count = 0;
    return &array[(*count)++];
}

/*checking if this filename is already stored for the user*/
static int file_exists_for_user(struct user_access_list *entry,
                                const char *filename)
{
    for (int i = 0; i < entry->file_count; ++i) {
        if (strcmp(entry->files[i], filename) == 0) {
            return 1;
        }
    }
    return 0;
}

/*adding new distinct filename to user's list */
static void add_file_to_user(struct user_access_list *entry,
                             const char *filename)
{
    if (!entry || !filename) return;
    if (entry->file_count >= MAX_FILES_PER_UID) return;
    if (file_exists_for_user(entry, filename)) return;

    entry->files[entry->file_count++] = strdup(filename);
}

/*return basename part of a path (after last '/')*/
static const char *get_basename_const(const char *path) {
    if (!path) return "";
    const char *slash = strrchr(path, '/');
    return (slash ? slash + 1 : path);
}

/* -s */

/* implement -s: list each UID with the set of files where denied=1 occurred.
 */
static void list_unauthorized_accesses(FILE *fp) {
    char linebuf[MAX_BUFFER_SIZE];
    struct user_access_list user_entries[MAX_USER_ENTRIES];
    int user_count = 0;

    while (fgets(linebuf, sizeof(linebuf), fp)) {
        struct audit_record *rec = parse_record(linebuf);
        if (!rec) continue;

        if (rec->is_denied == 1) {
            struct user_access_list *user_entry =
                find_or_add_user(user_entries, &user_count, rec->user_id);

            if (user_entry) {
                const char *fname = rec->filepath ? rec->filepath : "-";
                add_file_to_user(user_entry, fname);
            }
        }

        free_record(rec);
    }

    printf("Unauthorized Accesses:\n");
    for (int i = 0; i < user_count; ++i) {
        printf("UID %d:", user_entries[i].uid);
        for (int j = 0; j < user_entries[i].file_count; ++j) {
            printf(" %s", user_entries[i].files[j]);
        }
        printf("\n");

        /*free all stored filenames*/
        for (int j = 0; j < user_entries[i].file_count; ++j) {
            free(user_entries[i].files[j]);
        }
    }
}

/*-i */

/*-i:
count successful writes per user */
struct user_write_stats {
    int uid;
    int write_count;
};

/*find existing stats entry or create one*/
static struct user_write_stats *find_or_add_writer(struct user_write_stats *array,
                                                   int *count,
                                                   int uid)
{
    for (int i = 0; i < *count; ++i) {
        if (array[i].uid == uid) {
            return &array[i];
        }
    }

    if (*count >= MAX_USER_ENTRIES) {
        return NULL;
    }

    array[*count].uid         = uid;
    array[*count].write_count = 0;
    return &array[(*count)++];
}

/* implement -i:match on absolute filename or basename, count writes (op_type=2, not denied)
 */
static void list_file_modifications(FILE *fp, const char *filename) {
    char linebuf[MAX_BUFFER_SIZE];
    struct user_write_stats user_stats[MAX_USER_ENTRIES];
    int stats_count = 0;

    const char *target_base = get_basename_const(filename);

    while (fgets(linebuf, sizeof(linebuf), fp)) {
        struct audit_record *rec = parse_record(linebuf);
        if (!rec) continue;

        if (rec->op_type == 2 && rec->is_denied == 0 && rec->filepath) {
            const char *entry_base = get_basename_const(rec->filepath);

            /*match either full path or just basename */
            if (strcmp(rec->filepath, filename) == 0 ||
                strcmp(entry_base, target_base) == 0)
            {
                struct user_write_stats *st =
                    find_or_add_writer(user_stats, &stats_count, rec->user_id);

                if (st) {
                    st->write_count += 1;
                }
            }
        }

        free_record(rec);
    }

    printf("File modifications for '%s':\n", filename);
    for (int i = 0; i < stats_count; ++i) {
        printf("UID %d -> %d modification(s)\n",
               user_stats[i].uid, user_stats[i].write_count);
    }
}

/*main */

/* Open log file and dispatch to -s / -i / -h */
int main(int argc, char **argv) {
    int opt;
    FILE *fp = fopen(LOGFILE_NAME, "r");
    if (!fp) {
        perror("open " LOGFILE_NAME);
        return 1;
    }

    optind = 1;
    while ((opt = getopt(argc, argv, "hi:s")) != -1) {
        switch (opt) {
            case 'i':
                if (!optarg) {
                    fprintf(stderr, "-i requires a filename\n");
                    show_usage();
                    fclose(fp);
                    return 1;
                }
                fseek(fp, 0, SEEK_SET);
                list_file_modifications(fp, optarg);
                break;

            case 's':
                fseek(fp, 0, SEEK_SET);
                list_unauthorized_accesses(fp);
                break;

            case 'h':
            default:
                show_usage();
                break;
        }
    }

    fclose(fp);
    return 0;
}
