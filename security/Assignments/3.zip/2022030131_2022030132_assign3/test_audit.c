#include <stdio.h>
#include <string.h>

int main(void) {

    /*create file and  write */
    const char *fname = "sample_output.txt";
    FILE *f = fopen(fname, "w");  // create
    if (f) {
        const char *msg1 = "Initial line\n";
        fwrite(msg1, 1, strlen(msg1), f);   // write
        fclose(f);                          // close
    }

    /*open again and append write */
    f = fopen(fname, "a");   // open
    if (f) {
        const char *msg2 = "Second line\n";
        fwrite(msg2, 1, strlen(msg2), f);
        fclose(f);
    }

    /*expected denied : open nonexistent file */
    FILE *g = fopen("no_such_file_abc.txt", "r");
    if (g) fclose(g);

    /*expected denied: write to directory */
    FILE *h = fopen("/etc", "w");
    if (h) fclose(h);

    /*expected denied:  restricted path */
    FILE *k = fopen("/root/protected.txt", "w");
    if (k) fclose(k);

    return 0;
}
