#!/bin/bash
# You are NOT allowed to change the files' names!
config="config.txt"
rulesV4="rulesV4"
rulesV6="rulesV6"

initial_reset(){
        iptables -F OUTPUT
        ip6tables -F OUTPUT

        iptables -P OUTPUT ACCEPT
        ip6tables -P OUTPUT ACCEPT
    }


function firewall() {
    if [ "$EUID" -ne 0 ];then
        printf "Please run as root.\n"
        exit 1
    fi
    if [ "$1" = "-config"  ]; then
        # Configure adblock rules based on domain names and IPs of $config file.
        # Write your code here...
        # ...
        # ...
        printf "config starts..initial reset first of rules \n"
        initial_reset #clean/reset previous rules
        printf "continue to reading config %s\n" "$config"

        egrep -v "^#|^$" "$config" | while IFS= read -r line #read config file ignore empty lines,comments
        do
         [ -z "${line//[[:space:]]/}" ] && continue

         printf "valid entry : %s\n" "$line"
        #if entry ip address
         if echo "$line" | grep -E -q '([0-9]{1,3}\.){3}[0-9]{1,3}' || echo "$line" | grep -q ':'; then
            if echo "$line" | grep -q '\.'; then
                    #for ipv4
                    printf "blocking IPv4: %s\n" "$line"
                    #reject incoming/outgoing packets to/from the source IP
                    iptables -A OUTPUT -d "$line" -j REJECT
            elif echo "$line" | grep -q ':'; then
                    printf "blocking IPv6: %s\n" "$line"
                    #reject incoming/outgoing packets to/from the source IP
                    ip6tables -A OUTPUT -d "$line" -j REJECT
                fi
            else
            #if its not ipv4,ipv6 , its a domain name
            #resolve and block 
            dig +short A "$line" 2>/dev/null | while IFS= read -r ipv4_var; do 
                ipv4_var=$(echo "$ipv4_var" | xargs)
                echo "$ipv4_var" | grep -E -q '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || continue
                printf "block ipv4: %s\n" "$ipv4_var"
                iptables -A OUTPUT -d "$ipv4_var" -j REJECT
            done

            dig +short AAAA "$line" 2>/dev/null | while IFS= read -r ipv6_var; do
                ipv6_var=$(echo "$ipv6_var" | xargs)
                echo "$ipv6_var" | grep -E -q '^[0-9a-fA-F:]+$' || continue
                printf "block ipv6: %s\n" "$ipv6_var"
                ip6tables -A OUTPUT -d "$ipv6_var" -j REJECT
            done 
               fi
            done
        true
        
    elif [ "$1" = "-save"  ]; then
        # Save rules to $rulesV4/$rulesV6 files.
        # Write your code here...
        # ...
        # ...
        printf "saving to rulesV4\n"
        iptables-save > "$rulesV4"

        printf "saving to rulesV6\n"
        ip6tables-save > "$rulesV6"
        true
        
    elif [ "$1" = "-load"  ]; then
        # Load rules from $rulesV4/$rulesV6 files.
        # Write your code here...
        # ...
        # ...
        printf "loading IPv4 rules\n"
        iptables-restore < "$rulesV4"

        printf "loading IPv6 rules\n"
        ip6tables-restore < "$rulesV6"
        true

        
    elif [ "$1" = "-reset"  ]; then
        # Reset IPv4/IPv6 rules to default settings (i.e. accept all).
        # Write your code here...
        # ...
        # ...
        printf "reset IPv4 OUTPUT\n"
        iptables -F OUTPUT
        iptables -P OUTPUT ACCEPT
        

        printf "reset IPv6 OUTPUT\n"
        ip6tables -F OUTPUT
        ip6tables -P OUTPUT ACCEPT
        true

        
    elif [ "$1" = "-list"  ]; then
        # List IPv4/IPv6 current rules.
        # Write your code here...
        # ...
        # ...
        printf "List IPv4 rules\n"
        iptables -L OUTPUT -n -v --line-numbers
        printf "List IPv6 rules\n"
        ip6tables -L OUTPUT -n -v --line-numbers
        true
        
    elif [ "$1" = "-help"  ]; then
        printf "This script is responsible for creating a simple firewall mechanism. It rejects connections from specific domain names or IP addresses using iptables/ip6tables.\n\n"
        printf "Usage: $0  [OPTION]\n\n"
        printf "Options:\n\n"
        printf "  -config\t  Configure adblock rules based on the domain names and IPs of '$config' file.\n"
        printf "  -save\t\t  Save rules to '$rulesV4' and '$rulesV6'  files.\n"
        printf "  -load\t\t  Load rules from '$rulesV4' and '$rulesV6' files.\n"
        printf "  -list\t\t  List current rules for IPv4 and IPv6.\n"
        printf "  -reset\t  Reset rules to default settings (i.e. accept all).\n"
        printf "  -help\t\t  Display this help and exit.\n"
        exit 0
    else
        printf "Wrong argument. Exiting...\n"
        exit 1
    fi
}

firewall $1
exit 0