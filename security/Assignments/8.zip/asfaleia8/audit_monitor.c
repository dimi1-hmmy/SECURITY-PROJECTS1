#define _XOPEN_SOURCE 700
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX 4096
#define MAXE 20000
#define WINDOW 1200
#define DEFAULT_X 3

typedef struct {
    int uid;
    int pid;
    char file[MAX];
    time_t t;
    int op;
} entry;

static int ends_with(const char *s, const char *suf) {
    size_t l1 = strlen(s), l2 = strlen(suf);
    return l1 >= l2 && strcmp(s + l1 - l2, suf) == 0;
}

static time_t parse_time_utc(const char *date, const char *time_s) {
    struct tm tm;
    memset(&tm, 0, sizeof(tm));
    if (!strptime(date, "%Y-%m-%d", &tm)) return (time_t)-1;
    
    int h, m, s;
    if (sscanf(time_s, "%d:%d:%d", &h, &m, &s) != 3) return (time_t)-1;
    tm.tm_hour = h;
    tm.tm_min  = m;
    tm.tm_sec  = s;

    return timegm(&tm);
}

int main(int argc, char *argv[]) {
    int X = DEFAULT_X;
    if (argc >= 2) X = atoi(argv[1]);
    if (X <= 0) X = DEFAULT_X;

    FILE *f = fopen("access_audit.log", "r");
    if (!f) {
        perror("access_audit.log");
        return 1;
    }

    entry *e = malloc(MAXE * sizeof(entry)); 
    int n = 0;
    char line[MAX];

    while (fgets(line, sizeof(line), f) && n < MAXE) {
        line[strcspn(line, "\r\n")] = 0;
        if (strlen(line) < 10) continue;

        char *save = NULL;
        char *u_s    = strtok_r(line, "|", &save);
        char *p_s    = strtok_r(NULL, "|", &save);
        char *path   = strtok_r(NULL, "|", &save);
        char *date_s = strtok_r(NULL, "|", &save);
        char *time_s = strtok_r(NULL, "|", &save);
        char *op_s   = strtok_r(NULL, "|", &save);
        char *denied = strtok_r(NULL, "|", &save);
        char *hash   = strtok_r(NULL, "|", &save);

        if (!u_s || !p_s || !path || !date_s || !time_s || !op_s) continue;

        e[n].uid = atoi(u_s);
        e[n].pid = atoi(p_s);
        strncpy(e[n].file, path, MAX - 1);
        e[n].file[MAX - 1] = '\0';
        e[n].t = parse_time_utc(date_s, time_s);
        e[n].op = atoi(op_s);

        if (e[n].t != (time_t)-1) n++;
    }
    fclose(f);

    printf("--- RANSOMWARE DETECTION ---\n");
    printf("Threshold: %d files / 20 mins\n\n", X);

    // 1. Burst Detection
    for (int i = 0; i < n; i++) {
        int count = 0;
        for (int j = 0; j < n; j++) {
            if (e[i].uid == e[j].uid && e[j].op == 0 &&
                llabs((long long)e[j].t - (long long)e[i].t) <= WINDOW) {
                count++;
            }
        }
        if (count >= X) {
            printf("[ALERT][BURST] UID %d created %d files in 20min\n", e[i].uid, count);
            break; 
        }
    }

    // 2. Encryption Workflow Detection
    int enc_found = 0;
    for (int i = 0; i < n; i++) {
        if (e[i].op == 1 && !ends_with(e[i].file, ".enc")) {
            for (int j = 0; j < n; j++) {
                if (e[j].op == 0 && ends_with(e[j].file, ".enc")) {
                    char temp[MAX];
                    strncpy(temp, e[j].file, MAX-1);
                    temp[MAX-1] = '\0';
                    if (strlen(temp) > 4) {
                        temp[strlen(temp)-4] = '\0';
                        if (strcmp(temp, e[i].file) == 0 && e[i].pid == e[j].pid) {
                            printf("[ALERT][ENC] PID %d: '%s' -> '%s'\n", e[i].pid, e[i].file, e[j].file);
                            enc_found = 1;
                        }
                    }
                }
            }
        }
    }

    if (!enc_found) printf("No encryption patterns detected.\n");

    free(e);
    return 0;
}
