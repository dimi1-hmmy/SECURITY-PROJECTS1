from scapy.all import *
from datetime import datetime
import random

##packet
src_ip= ".".join(str(random.randint(1,254)) for _ in range(4))
dst_ip= "192.168.1.1"
dst_port= 54321

time= datetime.now().strftime("%Y-%m-%d %H:%M:%S")
payload= "Dimitra-2022030132" + time
 
packet= IP(src=src_ip, dst=dst_ip) / TCP(dport=dst_port) / Raw(load=payload)
#saving to PCAP
wrpcap("student_packet.pcap",packet)

#scan packets

services= {

    "HTTP": 80,
    "HTTPS": 443,
    "SSH": 22,
    "TELNET": 23,
    "FTP": 21,
    "DNS": 53,
    "RTSP": 554,
    "SQL": 1433,
    "RDP": 3389,
    "MQTT": 1883
}

packets = []

for service, port in services.items():
    src_ip = ".".join(str(random.randint(1,254)) for _ in range(4))
    dst_ip = "192.168.1.2"
    time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    payload = f"Dimitra-2022030132 {time}"

    pkt = IP(src=src_ip, dst=dst_ip) / TCP(dport=port) / Raw(load=payload)
    packets.append(pkt)

wrpcap("portscan_packets.pcap", packets)

import base64

#base 64 

idstudent="2022030132"
payloadb64= base64.b64encode(idstudent.encode()).decode()

packets=[]

for _ in range(5):
      src_ip= ".".join(str(random.randint(1,254)) for _ in range(4))
      dst_ip= "192.168.1.3"
      dport= 8080

      pkt= IP(src=src_ip, dst=dst_ip) / TCP(dport=dport) / Raw(load=payloadb64)
      packets.append(pkt)

wrpcap("base64_malicious_packet.pcap" , packets)

#dns

dns_ip="127.0.0.53"
src_ip=".".join(str(random.randint(1,254)) for _ in range(4))

dns_pkt = IP(src=src_ip, dst=dns_ip) / UDP(dport=53) / DNS(

rd=1,
qd=DNSQR(qname="malicious.example.com")
)

wrpcap("dns_suspicious_dp.pcap", dns_pkt)

#ping test packet

scp_ip =  ".".join(str(random.randint(1,254)) for _ in range(4))
icmp_pkt = IP(src=src_ip, dst="192.168.1.4") / ICMP() / Raw(load="PingTest-2024")

wrpcap("ping_test_packet.pcap", icmp_pkt)




