docker stop snort3
docker container rm snort3
docker run --name snort3 -h snort3 -u snorty -w /home/snorty/examples/intro/lab1 -v /home/student/Desktop/assignment7/snort/lab:/home/snorty/examples/intro/lab1 -it ciscotalos/snort3 bash
